<template>
    <div>
        dfdfgdfgdfg
    </div>
</template>

<script>
export default {
    mounted() {
    }
}
</script>

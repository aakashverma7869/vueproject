<template>
    <div>
        <home-component v-if="IS_HOME"></home-component>
        <apartment-step-one-component v-if="PROPERTIES.apartment.show"></apartment-step-one-component>
    </div>
</template>

<script>
import {mapGetters} from "vuex";

export default {
        mounted() {

        },

        computed: {
            ...mapGetters([
                'IS_HOME',
                'PROPERTIES'
            ]),
        }
    }
</script>

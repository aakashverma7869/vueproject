import Vue from 'vue'

import Vuex from 'vuex'

Vue.use(Vuex);

export default new Vuex.Store({
    state: {
        isHome: true,
        step: null,
        properties: {
            apartment: {
                show: false
            }
        }
    },

    mutations: {
        UPDATE_IS_HOME(state, data){
            state.isHome = data;
        },

        UPDATE_PROPERTY(state, data){
            state.properties[data].show = true;
        },

        UPDATE_STEP(state, data){
            state.step = data;
        }
    },

    actions: {},

    getters: {
        IS_HOME(state){
            return state.isHome
        },

        PROPERTIES(state){
            return state.properties
        },

        STEP(state){
            return state.step
        }

    }
});

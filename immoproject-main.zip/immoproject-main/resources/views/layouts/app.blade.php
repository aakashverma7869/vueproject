<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <script src="https://smtpjs.com/v3/smtp.js"></script>
    <meta charset="utf-8">
    <link rel="icon" type="image/x-icon" href="/images/favicon.ico">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta charset="utf-8">
    <title>McMakler &gt;&gt; Ihr Immobilienmakler für den Immobilienverkauf</title>
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1">
    <meta name="description"
          content="Immobilienmakler für Immobilien deutschlandweit ✔ Kostenlose Bewertung ✔ Individuelle Vermarktung ✔ TÜV-zertifiziert">
    <meta name="robots" content="noindex">
    <link rel="alternate" hreflang="de-AT" href="https://www.mcmakler.at">
    <link rel="alternate" hreflang="fr-FR" href="https://www.mcmakler.fr">
    <link rel="preconnect" href="https://app.usercentrics.eu">
    <link rel="preconnect" href="https://api.usercentrics.eu">
    <link rel="preconnect" href="https://aggregator.service.usercentrics.eu">
    <link rel="preconnect" href="https://graphql.usercentrics.eu">
    <link rel="preconnect" href="https://a.storyblok.com">
    <link rel="preconnect" href="https://img2.storyblok.com">
    <link rel="preconnect" href="https://emailsignature.trustpilot.com">
    <link rel="preconnect" href="https://www.googletagmanager.com">
    <link rel="preconnect" href="https://sslwidget.criteo.com">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100&amp;family=Rubik:wght@300&amp;display=swap"
          rel="stylesheet">
    <meta name="theme-color" content="#000000">
    <meta name="description" content="">
    <style>a, button, h1, h2, h3, h4, h5, h6, p, span {
            font-family: Rubik, sans-serif !important
        }</style>
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link href="{{ asset('css/style.css') }}" rel="stylesheet">
    @yield('css')
</head>
<body>
<div id="app">
{{--    @include('partials.header')--}}
    @yield('content')
{{--    @include('partials.footer')--}}
</div>

<script src="{{ mix('/js/app.js') }}"></script>

@yield('scripts')

</body>
</html>
